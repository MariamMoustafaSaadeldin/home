package com.example.earbudsapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText ed1, ed2;
    TextView tv1, tv2, tv3;
    Button btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ed1=(EditText) findViewById(R.id.ed1_20f20184);
        ed2=(EditText) findViewById(R.id.ed2_20f20184);
        tv1=(TextView) findViewById(R.id.tv1_20f20184);
        tv2=(TextView) findViewById(R.id.tv2_20f20184);
        tv3=(TextView) findViewById(R.id.tv3_20f20184);
        btn1=(Button) findViewById(R.id.b1_20f20184);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ee=new Intent(getApplicationContext(), MainActivity2.class);
                startActivity(ee);


            }
        });



    }
}